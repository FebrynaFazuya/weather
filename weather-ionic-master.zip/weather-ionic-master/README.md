# weather-ionic

Installation
1. Open your terminal in this project folder.
2. run npm install.
3. run ionic serve
